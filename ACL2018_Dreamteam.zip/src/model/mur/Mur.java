package model.mur;

public class Mur {

    private int posX,posY;

    public Mur(int x, int y){
        this.posX = x;
        this.posY = y;
    }

    public int getPosX(){
        return posX;
    }

    public int getPosY(){
        return posY;
    }


}
